# leaf-diseases-detect
It's able to detect 33 type of leaf diseases by using Deep learning.. I use transfer learning on the project. For More Information read my code. 



Model_link : https://drive.google.com/file/d/11BAit2Oc98PRxY_x6kOwKY9TTbIlurrB/view?usp=sharing
